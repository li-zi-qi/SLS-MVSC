
addpath('datasets/');
addpath('fun/');

load("100leaves.mat");
X = data';
gt = truelabel{1}';
class_num = length(unique(gt)); 
N = size(X{1},1);

lambda1 = 0.001;
lambda2 = 0.1;
lambda3 = 100;
lambda4 = 1;
test_num = 5; 

result = zeros(test_num,7); 
run_times = zeros(test_num,1); 

for i = 1:test_num

    run_start = tic;
    

    [S] = test(X, lambda1, lambda2, lambda3, lambda4);


    Y_pred = Ng_SpectralClustering(S, class_num);


    run_time = toc(run_start);
    run_times(i) = run_time;


    [ACC, NMI, PUR] = ClusteringMeasure(gt, Y_pred);
    [Fscore, Precision, Recall] = compute_f(gt, Y_pred);
    [AR, ~, ~, ~] = RandIndex(gt, Y_pred);


    result(i,:) = [ACC, NMI, PUR, Fscore, Precision, Recall, AR];


    fprintf('Run %d: ACC=%.4f, NMI=%.4f, PUR=%.4f, Fscore=%.4f, Precision=%.4f, Recall=%.4f, AR=%.4f, Time=%.4f秒\n', ...
        i, ACC, NMI, PUR, Fscore, Precision, Recall, AR, run_time);
end


mean_result = mean(result, 1);
std_result = std(result, 0, 1);
mean_time = mean(run_times);  
std_time = std(run_times);    

fprintf('Average results over %d runs:\n', test_num);
fprintf('ACC=%.4f ± %.4f, NMI=%.4f ± %.4f, PUR=%.4f ± %.4f, Fscore=%.4f ± %.4f, Precision=%.4f ± %.4f, Recall=%.4f ± %.4f, AR=%.4f ± %.4f\n', ...
    mean_result(1), std_result(1), ...
    mean_result(2), std_result(2), ...
    mean_result(3), std_result(3), ...
    mean_result(4), std_result(4), ...
    mean_result(5), std_result(5), ...
    mean_result(6), std_result(6), ...
    mean_result(7), std_result(7));